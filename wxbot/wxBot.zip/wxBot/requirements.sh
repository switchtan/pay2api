pip install pipreqs
pipreqs ./
pip install -r requirements.txt