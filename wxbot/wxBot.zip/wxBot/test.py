#!/usr/bin/env python
# coding: utf-8
#
from wxbot import *
from pprint import pprint
from httpget.httpHelp import httpget
import time
class MyWXBot(WXBot):
    def handle_msg_all(self, msg):
        # if self.DEBUG:
        #     print self.my_account['UserName']
        # if self.DEBUG and msg['content']['type'] == 7:
        #     print('guava msg_type_id:'+str(msg['msg_type_id']))
        #     pprint(msg)
        if msg['msg_type_id'] == 5 and msg['content']['type'] == 7:
            # self.send_msg_by_uid(u'hi', msg['user']['id'])
            # print('in httpHelp.py')
            # pprint(msg)
            filename = msg['content']['data']['title'].encode('utf-8')
            if filename.find('微信支付收款')>-1:
               start_index=filename.find('微信支付收款')+len('微信支付收款')
               end_index=filename.find("元(朋友到店)")
               money=filename[start_index:end_index]
               print(filename[start_index:end_index])
               print('form:')
               print(msg['user']['name'].encode('utf-8'))
               print('to:')
               print(msg['to_user_id'].encode('utf-8'))
               url = "http://pay.ds3336.com/getMoney.php?mid="+msg['to_user_id'].encode('utf-8')
               +'&money='+money+'&date'+time.time()
               getHtml= httpget(url)
               if getHtml == 'ok':
                   print 'guava'
               else:
                   print 'no ok'


            # print(msg['user']['id'])

            #self.send_img_msg_by_uid("img/1.png", msg['user']['id'])
            #self.send_file_msg_by_uid("img/1.png", msg['user']['id'])
'''
    def schedule(self):
        self.send_msg(u'张三', u'测试')
        time.sleep(1)
'''


def main():
    bot = MyWXBot()
    bot.DEBUG = True
    bot.conf['qr'] = 'png'
    bot.run()


if __name__ == '__main__':
    main()
