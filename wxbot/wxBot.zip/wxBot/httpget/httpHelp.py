import urllib
import urllib2
def httpget(url):
    req = urllib2.Request(url)
    response = urllib2.urlopen(req)
    return response.read()
