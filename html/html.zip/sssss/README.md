
# hAdmin
hAdmin是一个免费的后台管理模版,该模版基于bootstrap与jQuery制作，集成了众多常用插件，基本满足日常后台需要,修改时可根据自身需求，来定制后台模版，如需深度二次开发与定制，可联系我 QQ: 497915773

# Demo
![名称](./img/1.png)
> [hAdmin演示地址](https://fzninja.github.io/demo/hAdmin/#)


## beta _测试版_


